/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package prog5121poe2023final;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Sammy Guergachi <sguergachi at gmail.com>
 */
public class LoginTest {
    
    public LoginTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of run method, of class Login.
     */
    @Test
    public void testRun() {
        System.out.println("run");
        Login.run();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of housekeeping method, of class Login.
     */
    @Test
    public void testHousekeeping() {
        System.out.println("housekeeping");
        Login.housekeeping();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLoginUsername method, of class Login.
     */
    @Test
    public void testGetLoginUsername() {
        System.out.println("getLoginUsername");
        String expResult = "";
        String result = Login.getLoginUsername();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLoginPassword method, of class Login.
     */
    @Test
    public void testGetLoginPassword() {
        System.out.println("getLoginPassword");
        String expResult = "";
        String result = Login.getLoginPassword();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLoginFirstName method, of class Login.
     */
    @Test
    public void testGetLoginFirstName() {
        System.out.println("getLoginFirstName");
        String loginUsername = "";
        String loginPassword = "";
        String expResult = "";
        String result = Login.getLoginFirstName(loginUsername, loginPassword);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLoginLastName method, of class Login.
     */
    @Test
    public void testGetLoginLastName() {
        System.out.println("getLoginLastName");
        String loginUsername = "";
        String loginPassword = "";
        String expResult = "";
        String result = Login.getLoginLastName(loginUsername, loginPassword);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class Login.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String loginUsername = "";
        String loginPassword = "";
        boolean expResult = false;
        boolean result = Login.loginUser(loginUsername, loginPassword);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of returnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        boolean valid = false;
        String loginFirstName = "";
        String loginLastName = "";
        String expResult = "";
        String result = Login.returnLoginStatus(valid, loginFirstName, loginLastName);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
