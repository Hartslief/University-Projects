
package mobiledeviceapplication;

import javax.swing.JOptionPane;


public class MobileDeviceApplication {
    public static int[] deviceID = new int[3];
    public static String[] deviceName = new String[3];
    public static double[] devicePrice = new double[3];

    public static void main(String[] args) {
        

        //Menu system
        menu();
    }
    
    public static void menu(){
        int userSelection = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter(1) to add devices.\nEnter(2) to search for device details.\nEnter(3) to display all the device details.\nEnter(0) to exit.\n"));
        switch(userSelection){
            case 0:
                JOptionPane.showMessageDialog(null, "Thank you for using the Mobile Device Application!");
                System.exit(0);
            case 1: 
                loadArray();
                menu();
                break;
            case 2:
                searchArray();
                menu();
                break;
            case 3:
                display();
                menu();
                break;
            default:
                JOptionPane.showMessageDialog(null,"Invalid Option! Please try again.");
                menu();
                break;
        }
    }
    
    
    public static void loadArray(){
        for(int i = 0; i < deviceID.length; i++){
            deviceID[i] = Integer.parseInt(JOptionPane.showInputDialog(null,"Please enter the ID for Device " + (i + 1)));

            deviceName[i] = JOptionPane.showInputDialog(null, "Please enter the name for Device " + deviceID[i]);

            devicePrice[i] = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter the price for Device " + deviceID[i]));
        }
    }
    
    public static void searchArray(){
        int getDeviceID = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the Device ID: "));
        
        for(int i = 0; i < deviceID.length; i++){
            if(getDeviceID == deviceID[i]){
                JOptionPane.showMessageDialog(null, "PRODUCT ID: " + deviceID[i] + "\nPRODUCT: " + deviceName[i] + "\nPRICE: R" + devicePrice[i]);
            }
        }
    }
    
    public static void display(){
        
        JOptionPane.showMessageDialog(null, "ID            DEVICE            PRICE" 
                                                        + "\n-------------------------------------\n"
                                                        + deviceID[0] + "           " + deviceName[0] + "           R" + devicePrice[0] + "\n"
                                                        + deviceID[1] + "           " + deviceName[1] + "           R" + devicePrice[1] + "\n"
                                                        + deviceID[2] + "           " + deviceName[2] + "           R" + devicePrice[2] + "\n"
                                                        + "DEVICE COUNT : " + deviceID.length);

    }
}
